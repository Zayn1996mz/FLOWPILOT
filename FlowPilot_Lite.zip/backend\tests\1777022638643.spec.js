import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://dhaquetta.org/');
  await page.locator('span').nth(2).click();
  await page.getByRole('link', { name: 'Member Login' }).click();
  await page.getByRole('textbox', { name: 'Username' }).click();
  await page.getByRole('textbox', { name: 'Username' }).click();
  await page.getByRole('textbox', { name: 'Username' }).fill('45234523');
  await page.getByRole('textbox', { name: 'Password' }).click();
  await page.getByRole('textbox', { name: 'Password' }).fill('4523452345');
  await page.getByRole('button', { name: 'SIGN IN' }).click();
});