# FlowPilot - SQA Automation Tool

FlowPilot is a powerful, full-stack web automation application that allows you to record browser interactions, parameterize them with Excel data, and run them as automated test cases with detailed reporting.

Developed by **Zain Shahid**.

## 🚀 Features
- **Intelligent Recorder**: Capture web interactions using Playwright codegen.
- **Data-Driven Testing**: Map Excel/CSV columns to form inputs for bulk execution.
- **Batch Processing**: Run multiple test scripts sequentially.
- **Looping**: Repeat test suites multiple times.
- **Visible Execution**: Watch tests run live with `slowMo` and headful browser support.
- **Comprehensive Reports**: View detailed logs and pass/fail status for every iteration.
- **Responsive Design**: Modern, glassmorphism UI that works on all devices.

## 🛠 Tech Stack
- **Frontend**: React, Vite, React Router, Lucide Icons, Axios.
- **Backend**: Node.js, Express, Playwright, XLSX, Multer.
- **Styling**: Vanilla CSS with modern dark-mode aesthetics.

## 📂 Project Structure
- `/backend`: Node.js server, test scripts, uploads, and execution reports.
- `/frontend`: React application (Vite).
- `/FlowPilot-ChromeExtension`: (Optional) Packaged Chrome Extension version.

## ⚙️ Installation & Setup

1. **Clone the repository** (on your local machine).
2. **Install Backend Dependencies**:
   ```bash
   cd backend
   npm install
   ```
3. **Install Frontend Dependencies**:
   ```bash
   cd ../frontend
   npm install
   ```
4. **Run the Application**:
   - Start Backend: `node server.js` (in `/backend`)
   - Start Frontend: `npm run dev` (in `/frontend`)

## 📄 License
Created for educational and professional SQA automation purposes. Developed by Zain Shahid.
