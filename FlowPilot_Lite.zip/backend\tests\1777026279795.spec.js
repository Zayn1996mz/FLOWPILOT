import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://dhaquetta.org/');
  await page.locator('.hamburger').click();
  await page.getByRole('link', { name: 'Member Login' }).click();
  await page.getByRole('textbox', { name: 'Username' }).click();
  await page.getByRole('textbox', { name: 'Username' }).fill('544009777877');
  await page.getByRole('textbox', { name: 'Username' }).press('Tab');
  await page.getByRole('textbox', { name: 'Password' }).fill('test');
  await page.getByRole('button', { name: 'SIGN IN' }).click();
});